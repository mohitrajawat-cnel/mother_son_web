<?php
    global $wpdb;
        
?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<?php
	$domain_id = $_REQUEST['edit'];
	
    $message='';
    if(isset($_POST['update_domain']))
    {
    	$domain_status = $_POST['status'];
        $domain_type = $_POST['domain_status'];
      
        
        $update = "UPDATE domain_list_setting SET status='$domain_status',domain_status='$domain_type' where id='$domain_id'";
        $wpdb->query($update);
    }
    
     $select = "SELECT id, domain_name, status,domain_status FROM domain_list_setting WHERE id='$domain_id'";
     $results = $wpdb->get_results($select,ARRAY_A);
     foreach($results as $value)
     {
         $id = $value['id'];
         $status = $value['status'];
         $domain_type = $value['domain_status'];
         $domain_name = $value['domain_name'];
     }
    
    ?>
    <main id="" class="mt-5 container">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<div class="container-fluid">
					<a class="navbar-brand " href="#">Update&nbsp;<b><?php echo $domain_name; ?></b>&nbsp;Site</a>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
					</div>
				</div>
		</nav>
		<span class="success success_alert" style="<?php echo $stylehwe; ?>"><?php echo $message; ?></span>
		<section>
			<div class="container">
				<div class="row d-flex">
					<div class="col-sm-12 justify_content-center">
						<form id="form_id" method="post">
							<input type="hidden" name="prifix" value='xyz_'>
						
						
							<div class="mb-3">
								<label for="name" class="form-label">Domain Type</label>
    							<select class="form-control" name="domain_status">
                                  <option value="1" <?php if($domain_type == 1){ echo 'selected'; } ?>>Mother Domain</option>
                                  <option value="0" <?php if($domain_type == 0){ echo 'selected'; } ?>>Son Domain</option>
                                </select>
							</div>
							<div class="mb-3">
								<label for="name" class="form-label">Status</label>
								<select class="form-control" name="status">
                                    <option value="0" <?php if($status == 0){ echo 'selected'; } ?>>Active</option>
                                    <option value="1" <?php if($status == 1){ echo 'selected'; } ?>>Inactive</option>
                                </select>
							</div>
                            <br>
							<button type="submit" name="update_domain" class="btn btn-primary">Update Domain</button>
						</form>
					</div>
				</div>

			</div>

		</section>

	</main>
   