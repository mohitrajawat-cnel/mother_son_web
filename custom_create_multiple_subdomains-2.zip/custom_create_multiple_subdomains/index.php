<?php
/**
* Plugin Name: Custom Son Create Form
* Plugin URI: https://www.your-site.com/
* Description: Create mother son using custom form and create domains-subdomains.
* Version: 0.1
* Author: Hire Wordpress Expert
* Author URI: https://www.your-site.com/
**/

// create add menu function





/**
 * Activate the plugin.
 */
function custom_function() {
    global $wpdb;
    $domain_server_name = $_SERVER['SERVER_NAME'];

    $select_domain_status = "SELECT * FROM domain_list_setting WHERE domain_name = '$domain_server_name'";

    $result = $wpdb->get_results($select_domain_status);
  
    if ($result) {
        
        foreach ($result as $row) {
          
            $domain_status = $row->domain_status;
            
            
            if($domain_status==1){
                
                active_function();
            }
            else{
                
            }
           
        }
        
    } 
}
 add_action( 'init', 'custom_function' );


function active_function(){

    add_action( 'admin_menu', 'wpdocs_register_my_custom_menu_page' );
}


function wpdocs_register_my_custom_menu_page() {
   
   
        add_menu_page(
            __( 'Mother Son Websites', 'textdomain' ),
            'Mother Son Website',
            'manage_options',
            'son_website',
            'son_website_function',
            6
        );

        add_submenu_page(
            'son_website',
            __( 'Submenu Page', 'textdomain' ),
            'domain list setting',
            'manage_options',
            'son_website_submenu',
            'son_website_submenu_function'
        );
      
    }
    
 







function son_website_submenu_function() {
    global $wpdb;
    
    if (isset($_POST['delete'])) 
    {
       $rowId = $_POST['delete'];

       // Perform the deletion query
       $deleteQuery = $wpdb->prepare("DELETE FROM domain_list_setting WHERE id = %d", $rowId);
       $wpdb->query($deleteQuery);
    }
    
    $select = "SELECT id, domain_name, status,domain_status FROM domain_list_setting";
    $results = $wpdb->get_results($select);


?>


<!DOCTYPE html>
<html>
    <head>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap4.min.js"></script>
        <!--<link rel="stylesheet" href="<?php echo get_site_url(); ?>/wp-content/plugins/custom_create_multiple_subdomains/bootstrap.css">-->
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap4.min.css">
        <script>
            
            $(document).ready(function () {
                $('#example').DataTable();
            });
        </script>
        
        <style>
        .custon_btn_style
        {
            color: #fff;
            background-color: #007bff;
            border-color: #007bff;
            
        }
        .page-item.active .page-link {
        	z-index: 3;
        	color: #fff;
        	background-color: #007bff;
        	border-color: #007bff;
        }
        .custon_btn_style {
        	display: inline-block;
        	font-weight: 400;
        	text-align: center;
        	vertical-align: middle;
        	padding: 0.375rem 0.75rem;
        	font-size: 1rem;
        	line-height: 1.5;
        	border-radius: 0.25rem;
        	transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
        .page-link
        {
            padding:10px;
        }
        
        </style>
    </head>
    <body>
        <h1>Domain List Setting</h1>
        <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Domain Name</th>
                    <th>Status</th>
                    <th>Domain Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                  if ($results) {
                     $i=0;
                    foreach ($results as $row) {
                      $i=$i+1;
                      $rowId = $row->id;
                      $domainName = $row->domain_name;
                      $status = $row->status;
                      $domain_status= $row->domain_status;
                      ?>
                      <tr>
                        <td><?php echo $i;?></td>
                        <td><?php echo $domainName; ?></td>
                        <td><?php echo $status; ?></td>
                        <td>
                          <?php
                            if ($domain_status == 1) {
                              echo "Mother Domain";
                            } else {
                              echo "Son Domain";
                            }
                          ?>
                        </td>
            
                        <td>
                          <form method="post">
                            <input type="hidden" name="delete" value="<?php echo $rowId; ?>">
                            <button type="submit" onclick="confirm('Are You Sure to delete <?php echo $domainName; ?>')" class="btn btn-primary custon_btn_style" style="cursor:pointor;">Delete</button>
                          </form>
                        </td>
                      </tr>
                      <?php
                    }
                  }
                 ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>#</th>
                    <th>Domain Name</th>
                    <th>Status</th>
                    <th>Domain Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
    </body>
</html>
<?php
}




function son_website_function()
{ 
  
	global $wpdb;
	
	
        
    ?>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<?php 
	 
    function randomtableprefix() {
    
        $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < 6; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
                
    $stylehwe = '';
    $message = '';
    
    if(isset($_POST['create_domain']))
    {
    
	$domain_name = $_POST['domain_name'];
    $status = $_POST['status'];
	$table_prifixs = randomtableprefix();
    $table_prifix  =  $table_prifixs."_";
    $created =date('Y-m-d H:i:s');
    $login_user=$_POST['login_user'];
    $login_password_md5=$_POST['login_password'];
    $login_password=md5( $login_password_md5);
    $login_email=$_POST['login_email'];
    $domain_status=$_POST['domain_status'];
    
    $query= $wpdb->prepare("SELECT COUNT(*) FROM `domain_list_setting` WHERE domain_name='$domain_name'");
     
    $result =  $wpdb->get_var($query);
  
    if($result <= 0)
    {
        
      
        $insert = $wpdb->prepare("INSERT INTO domain_list_setting (domain_name, table_prefix, status, created ,login_user,login_password,login_email,domain_status) VALUES (%s, %s, %s, %s,%s, %s, %s,%s)",
        $domain_name, $table_prifix, $status, $created,$login_user, $login_password, $login_email,$domain_status);

        if($wpdb->query($insert) !== false){


    
            $whmusername = "pdroot";
            $whmpassword = "QWFs.mC.8Z8xv8R";
            $cpanel_ip = '139.162.43.159'; //ip of cpanel or your_domain.com
            // $domain = "abc.com";
            $domain = "pixeldream.com.my";
            $document_root = "";
            
          
            $query = "https://".$cpanel_ip.":2083/json-api/cpanel?cpanel_jsonapi_module=SubDomain&cpanel_jsonapi_func=addsubdomain&cpanel_jsonapi_apiversion=2&dir=/public_html/".$document_root."/&rootdomain=".$domain."&domain=".$domain_name."";
            
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER,0);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,0);
            curl_setopt($curl, CURLOPT_HEADER,0);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER,1);
            $header[0] = "Authorization: Basic " . base64_encode($whmusername.":".$whmpassword) . "\n\r";
            curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
            curl_setopt($curl, CURLOPT_URL, $query);
            $result = curl_exec($curl);
            
            //  print_r($result);
            // echo "working";
            // die('========');
            
            curl_close($curl);
            $response= json_decode($result,true);
            $response = $response['cpanelresult'];
            $response = $response['data'][0]['result'];
                
            if($response == 1)
            {
                
       
            	   global $wpdb;
            
                    
                    $prefix = 'MHVQu6_';
                    $query = "SHOW TABLES LIKE %s";
                    $tables = $wpdb->get_results($wpdb->prepare($query, "{$prefix}%"), ARRAY_N);
                
                    if($tables) 
                    {
                        foreach ($tables as $table) 
                        {
                            $tableName = $table[0];
                            //echo $tableName . "<br>";
                            
                            
                            $newPrefix = $table_prifix;
                        
                            
                            $newTableName = str_replace('MHVQu6_', $newPrefix, $tableName);
                            
                            
                            
                            $createTableQuery = "CREATE TABLE $newTableName LIKE $tableName";
    				    
    				        if ($wpdb->query($createTableQuery)) 
    				        {
    				        
    				        $insertDataQuery = "INSERT INTO $newTableName SELECT * FROM $tableName";
    				        
                            	if ($wpdb->query($insertDataQuery)) 
                            	{
                                     $newTableName."Table duplicated successfully.<br>";
                                     if($newTableName==$table_prifix."users")
                                     {
                                          $update_query = "UPDATE $newTableName 
                                        SET user_login = '$login_user', 
                                        user_pass = '$login_password',
                                        user_nicename = '$login_user',
                                         user_email = '$login_email',
                                        user_url = 'https://".$domain_name."'";
                                        
                                        $wpdb->query($update_query);
                                        
                                        
                                    }
                                        
                                    if($newTableName==$table_prifix."usermeta")
                                    {
                                            
                                        $update_meta_key_capability = "UPDATE " . $newTableName . " SET meta_key= '".$table_prifix."capabilities' WHERE meta_key='MHVQu6_capabilities'";
                                        $wpdb->query($update_meta_key_capability);
                                 
                                        $update_meta_key_level = "UPDATE " . $newTableName . " SET meta_key= '".$table_prifix."user_level' WHERE meta_key='MHVQu6_user_level'";
                                        $wpdb->query($update_meta_key_level);
                            	    
                            	        $update_nickname = "UPDATE " . $newTableName . " SET meta_value= '$login_user' WHERE meta_key='nickname'";
                                        $wpdb->query($update_nickname);
                                      
                                        $update_dashborad = "UPDATE " . $newTableName . " SET meta_key= '".$table_prifix."dashboard_quick_press_last_post_id' WHERE meta_key='MHVQu6_dashboard_quick_press_last_post_id'";
                                        $wpdb->query($update_dashborad);
                                 
                                        $update_persisted = "UPDATE " . $newTableName . " SET meta_key= '".$table_prifix."persisted_preferences' WHERE meta_key='MHVQu6_persisted_preferences'";
                                        $wpdb->query($update_persisted);
                                      
                                        $update_user = "UPDATE " . $newTableName . " SET meta_key= '".$table_prifix."user-settings' WHERE meta_key='MHVQu6_user-settings'";
                                        $wpdb->query($update_user);
                                      
                                        $update_user_time = "UPDATE " . $newTableName . " SET meta_key= '".$table_prifix."user-settings-time' WHERE meta_key='MHVQu6_user-settings-time'";
                                        $wpdb->query($update_user_time);
                                      
                                        $update_dashboard_quick= "UPDATE " . $newTableName . " SET meta_key= '".$table_prifix."dashboard_quick_press_last_post_id' WHERE meta_key='MHVQu6_dashboard_quick_press_last_post_id'";
                                        $wpdb->query($update_dashboard_quick);
                                          
                                         
                                    }
                                        
                                    if($newTableName==$table_prifix."posts")
                                    {
                                             
                                       $select = "SELECT guid FROM $newTableName WHERE guid LIKE 'https://pixeldream.com.my%'";
        
                                        $results = $wpdb->get_results($select);
                                        
                                        foreach ($results as $row) {
                                            $guid = $row->guid;
                                            $modifiedGuid = str_replace('pixeldream.com.my', $domain_name, $guid);
                                           // echo $modifiedGuid . "<br>";
                                            
                                        }
                                         
                                    }
                                       
                                    if($newTableName==$table_prifix."options")
                                    {
                                           
                                        $updateQuery1sdfds = "UPDATE ".$newTableName." SET option_value ='https://".$domain_name."' WHERE option_name='siteurl'";
                                        $wpdb->query($updateQuery1sdfds);
                                        
                                        $updateQuery56562 = "UPDATE " . $newTableName . " SET option_value = 'https://" . $domain_name . "' WHERE option_name='home'";
                                        $wpdb->query($updateQuery56562);
                                      
                                      
                                        $update_option_name = "UPDATE " . $newTableName . " SET option_name = '".$table_prifix."user_roles' WHERE option_name='MHVQu6_user_roles'";
                                        $wpdb->query($update_option_name);
                                     
                                        $update_calendar = "UPDATE " . $newTableName . " SET option_name = '".$table_prifix."calendar_block_has_published_posts' WHERE option_name='MHVQu6_calendar_block_has_published_posts'";
                                        $wpdb->query($update_calendar);
                                    
                                    
                                        $update_adminify_version = "UPDATE " . $newTableName . " SET option_name = '".$table_prifix."adminify_version' WHERE option_name='MHVQu6_adminify_version'";
                                        $wpdb->query($update_adminify_version);
                                            
                                        $update_db_version = "UPDATE " . $newTableName . " SET option_name = '".$table_prifix."adminify_page_speed_db_version' WHERE option_name='MHVQu6_adminify_page_speed_db_version'";
                                        $wpdb->query($update_db_version);
                                     
                                        $update_rocket_settings = "UPDATE " . $newTableName . " SET option_name = '".$table_prifix."rocket_settings' WHERE option_name='MHVQu6_rocket_settings'";
                                        $wpdb->query($update_rocket_settings);
                                     
                                   
                                    }
                                }
        				    }
                        }
                        
                        $message = $domain_name." has been successfully created";
                        $stylehwe = "color: green;text-align: center;display: block;font-size: 20px;";
                    } 
                    else
                    {
                        $message = "For ".$domain_name." tables not found with the prefix '{$prefix}'.";
                        $stylehwe = "color: red;text-align: center;display: block;font-size: 20px;";
                    }
        
            }
             else
            {
                $message ="Error Creating ".$domain_name; 
                $stylehwe = "color: red;text-align: center;display: block;font-size: 20px;";
            }
                
        }
        else
        {
            $message ="Error Creating ".$domain_name; 
            $stylehwe = "color: red;text-align: center;display: block;font-size: 20px;";
        }
        
      }
      else
      {
        $message =$domain_name." domain already exist"; 
        $stylehwe = "color: red;text-align: center;display: block;font-size: 20px;";
      }
    }
    
    ?>
    <main id="" class="mt-5 container">
		
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
				<div class="container-fluid">
					<a class="navbar-brand " href="#">Create New Website</a>
					<div class="collapse navbar-collapse" id="navbarSupportedContent">
					</div>
				</div>
		</nav>
		<span class="success success_alert" style="<?php echo $stylehwe; ?>"><?php echo $message; ?></span>
		<section>
			<div class="container">
				<div class="row d-flex">
					<div class="col-sm-12 justify_content-center">
						<form id="form_id" method="post">
							<input type="hidden" name="prifix" value='xyz_'>
							<div class="mb-3">
								<label for="domainName" class="form-label">Domain Name</label>
								<input type="text" name="domain_name" class="form-control" id="domain_name" placeholder="Enter Domain Name" required />
							</div>
							<div class="mb-3">
								<label for="domainName" class="form-label">Login User</label>
								<input type="text" name="login_user" class="form-control" id="login_user" placeholder="Enter Username" required />
							</div>
							<div class="mb-3">
								<label for="domainName" class="form-label">Login Password</label>
								<input type="text" name="login_password" class="form-control" id="login_password" placeholder="Enter Password" required />
							</div>
							<div class="mb-3">
								<label for="domainName" class="form-label">Login Email</label>
								<input type="text" name="login_email" class="form-control" id="login_email " placeholder="Enter Email" required />
							</div>
							
								<div class="mb-3">
								<label for="name" class="form-label">Domain Status</label>
							<select class="form-control" name="domain_status">
                              <option value="1">Mother Domain</option>
                              <option value="0" selected>Son Domain</option>
                             
                            </select>

							</div>
							<div class="mb-3">
								<label for="name" class="form-label">Status</label>
								<select class="form-control" name="status">
                                    <option value="0">Active</option>
                                    <option value="1">Inactive</option>
                                </select>
							</div>
                            <br>
							<button type="submit" name="create_domain" class="btn btn-primary" value="submit">Create Domain</button>
						</form>
					</div>
				</div>

			</div>

		</section>

	</main>
    <?php
                
}

///update push on son website function
add_filter('page_row_actions', 'add_custom_action_checkbox', 10, 2);

function add_custom_action_checkbox($actions, $post) {
    
    
    global $wpdb;
    $select_domain_type = "SELECT * FROM domain_list_setting WHERE domain_name = '".$_SERVER['SERVER_NAME']."'";
    $result = $wpdb->get_results($select_domain_type);
    if ($result) 
    {
        $domain_status = 0;
        foreach ($result as $row) {
          
            $domain_status = $row->domain_status;
        }
        if($domain_status == 1)
        {
            global $wpdb;
            $get_update_push_value = get_post_meta($post->ID,"update_mother_pages_to_son",true);
        
            $checked = '';
            if((int)$get_update_push_value == 1)
            {
                $checked = "checked";
            }
            $actions['custom_action'] = '<lable style="color:#c82424; font-size:13px;">Push update to Son <input type="checkbox" '.$checked.' class="custom_update_add_push"
            data_post_id="'.$post->ID.'"></lable>';
    
        }
    }
    return $actions;
  
}

function send_data_post(){
    
    global $wpdb;
    $select_domain_type = "SELECT * FROM domain_list_setting WHERE domain_name = '".$_SERVER['SERVER_NAME']."'";
    $result = $wpdb->get_results($select_domain_type);
    if ($result) 
    { 
        $domain_status = 0;
        foreach ($result as $row) {
          
            $domain_status = $row->domain_status;
        }
        if($domain_status == 1)
        {
            global $wpdb;
            global $post;
            $post_id = $_POST['post_id'];
            $value = $_POST['value'];
            $response = update_post_meta($post_id,"update_mother_pages_to_son",$value);
            echo "Updated successfully";
            die();
        }
    }
   
}

add_action( 'wp_ajax_nopriv_send_data_post', 'send_data_post' );
add_action( 'wp_ajax_send_data_post', 'send_data_post' );

function ajax_for_send_post_data() {
    
    global $wpdb;
    $select_domain_type = "SELECT * FROM domain_list_setting WHERE domain_name = '".$_SERVER['SERVER_NAME']."'";
    $result = $wpdb->get_results($select_domain_type);
  

    if ($result) 
    {
        
        $domain_status = 0;
        foreach ($result as $row) {
          
            $domain_status = $row->domain_status;
        }
        if($domain_status == 1)
        {
        ?>
            <script>
                jQuery(document).ready(function(){
           
                    var checkbox_value = jQuery('.custom_update_add_push').val();
            
                    jQuery('.custom_update_add_push').click(function(){
                        
                        var data_post_id = jQuery(this).attr('data_post_id');
                        
                        if(jQuery(this).is(":checked"))
                        {
                    
                          var checkboxvalue = 1;
                        }
                        else
                        {
                          var checkboxvalue = 0;
                        }
                   
                
                        jQuery.ajax({
                            type: "post",
                            url: "<?php echo get_site_url(); ?>/wp-admin/admin-ajax.php",
                            data: {
                              action: "send_data_post",
                              "post_id":data_post_id,
                              "value":checkboxvalue
                            },
                            success: function (result) {
                                  alert(result);
                            }
                      });
                    });
                });
            </script>
        <?php
    
        }
    }
}
add_action('admin_head', 'ajax_for_send_post_data');
function custom_content_change_fun()
{
    global $wpdb;
    $select_domain_type = "SELECT * FROM domain_list_setting WHERE domain_name = '".$_SERVER['SERVER_NAME']."'";
    $result = $wpdb->get_results($select_domain_type);
  
 
    if ($result) {
        
     
        
        $domain_status = 0;
        foreach ($result as $row) {
          
            $domain_status = $row->domain_status;
        }

        if($domain_status == 0)
        {
            if($_SERVER['SERVER_NAME'] != "pixeldream.com.my")
            {
                
              
              
                $current_slug = get_post_field( 'post_name', get_post() );
                
                $page = $wpdb->get_row(
                $wpdb->prepare( "SELECT * FROM `MHVQu6_posts` WHERE post_name = %s AND post_type = 'page'", $current_slug )
                );
                
                if ( $page ) {
                    // Page found, access its properties
                    $page_id = $page->ID;
                    
                    $current_page_id = get_the_ID();
                    $current_page_slug = get_post_field('post_name', $current_page_id);
                    
                    $page_id = $wpdb->get_var(
                    $wpdb->prepare(
                            "SELECT ID FROM `MHVQu6_posts` WHERE post_name = %s AND post_type = 'page'",
                            $current_page_slug
                        )
                    );
        
                    if ($page_id) {
                        
                        $get_push_update_to_son_value= $wpdb->get_results("SELECT * FROM `MHVQu6_postmeta` WHERE post_id='$page_id'",ARRAY_A);
                        $push_update_value=0;
                        foreach($get_push_update_to_son_value as $get_push_update_to_son_value_hwe)
                        {
                            
                            if($get_push_update_to_son_value_hwe['meta_key'] == 'update_mother_pages_to_son')
                            {
                               
                                $push_update_value = $get_push_update_to_son_value_hwe['meta_value'];
                            }
                            
                        }
                   
                        if((int)$push_update_value == 1)
                        {
                            $page_id = $page_id;
                            //update post table data
                            $updat_post_content ="UPDATE ".$wpdb->prefix."posts
                            SET post_content = (SELECT post_content FROM `MHVQu6_posts` WHERE ID ='$page_id')
                            WHERE ID = '$current_page_id'";
                            $wpdb->query($updat_post_content);
                     
                            //update postmeta table elementor data
                            $post_contentsgdsg ="UPDATE ".$wpdb->prefix."postmeta SET meta_value = (SELECT meta_value FROM `MHVQu6_postmeta` WHERE post_id = '$page_id' AND meta_key = '_elementor_data')
                            WHERE post_id ='$current_page_id' AND meta_key = '_elementor_data'";
                            $wpdb->query($post_contentsgdsg);
                            
                        }
                        
                    } 
                }
             }
        }
    }
   
}
add_action('wp_head', 'custom_content_change_fun');
